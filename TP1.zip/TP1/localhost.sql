Update Drh Set sal = 3000
Where mat = 5617;

Update Drh Set sal = 500, vac = 700
Where mat = 5708;